README Project 1 COM S 352
Author: Thomas Haddy
Date: 3/15/19

Project contents:
- project-1-thomas-haddy.c
- Makefile
- input.txt
- README.txt

To compile the source code, go to the directory
named "Thomas_Haddy_Project1" in your terminal.

Next, type 'make' into your terminal. This should compile 'project-1-thomas-haddy.c'
and create an executable titled 'project-1'

Lastly, type './project-1' to run the shearsort algorithm on "input.txt" which contains
the 2D integer array to be sorted.

Note: To change the array you want sorted, change the contents of "input.txt" to create
      another 2D array. You won't need to 'make' again, just run the executble 'project-1'
